import java.awt.*;
import javax.swing.*;
public class Graphique extends JFrame{
    public static void main(String[] args){
        SwingUtilities.invokeLater(new Runnable() {
            public void run(){
                Graphique g = new Graphique();
                g.pack();
                g.setVisible(true);
            }
        });
    }
    
    private JComboBox<String> nom;
    private JPanel cPanel;
    private Color couleur;

    private static final String[] LIST = {
        "BLACK","RED","GREEN","BLUE"
    };

    public Graphique(){
        nom = new JComboBox<String>(LIST);
        couleur = new Color(3);
        this.cPanel = new JPanel();
        change(couleur);

        setLayout( new GridLayout(2,1));
        add(nom);
        add(cPanel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        nom.addItemListener(new Ecouteur(this));

    }

    public void change(int e){
        cPanel.setBackground(e);
    }

    public String getColor(){
        return nom.getSelectedItem().toString();
    }
}