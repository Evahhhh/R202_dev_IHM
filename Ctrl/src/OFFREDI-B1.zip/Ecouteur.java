import java.awt.event.*;
import java.awt.*;

public class Ecouteur implements ItemListener{
    Graphique g;
    public Ecouteur(Graphique g){
        this.g = g;
    }

    public void itemStateChanged(ItemEvent event) {
        Color e = 3;
        if(g.getColor() == "BLACK") g.change(e.getBlack());
        else if (g.getColor() == "RED")g.change(e.getRed());
        else if (g.getColor() == "GREEN")g.change(e.getGreen());
        else if (g.getColor() == "BLUE")g.change(e.getBlue());
    }
}
